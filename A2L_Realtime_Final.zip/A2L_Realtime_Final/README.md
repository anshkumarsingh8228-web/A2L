# Alone2Lone Real-Time Prototype

Deployment-ready prototype server for the existing A2L HTML UI.

## What it provides
- HTTPS-compatible same-origin WebSocket signaling
- 2-user room enforcement for prototype testing
- Real-time text message relay
- WebRTC offer/answer/ICE signaling
- Health endpoint at `/health`
- Existing A2L HTML UI preserved

## Important
The browser needs HTTPS for camera/microphone access (localhost is the development exception). Deploy the folder as a Node.js web service.

For WebRTC connectivity, the client includes public STUN servers. A TURN server should be configured for reliable connectivity across restrictive networks before production use.

## Two-device test
1. Deploy this folder as a Node.js service.
2. Open the resulting HTTPS URL on both devices.
3. Use the same `?room=TEST123` on both devices.
4. Start a video/voice session from the existing A2L session UI.
5. Allow camera/microphone permissions on both devices.

This is still a prototype transport layer; production needs authenticated users, matchmaking, persistent messaging, abuse controls, rate limiting, TURN credentials, and a database.
