const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const WebSocket = require('ws');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = __dirname;
const MAX_ROOM_SIZE = 2;
const rooms = new Map();

function json(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(data);
}

function serve(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/health') return json(res, 200, {ok:true, service:'a2l-realtime'});
  if (url.pathname === '/rtc-config') {
    const iceServers = [
      {urls:['stun:stun.l.google.com:19302','stun:stun1.l.google.com:19302']}
    ];
    if (process.env.TURN_URL && process.env.TURN_USERNAME && process.env.TURN_CREDENTIAL) {
      iceServers.push({urls:process.env.TURN_URL.split(',').map(s=>s.trim()).filter(Boolean), username:process.env.TURN_USERNAME, credential:process.env.TURN_CREDENTIAL});
    }
    return json(res, 200, {iceServers});
  }
  let file = url.pathname === '/' ? '/Alone2Lone_A2L_New.html' : decodeURIComponent(url.pathname);
  if (file.includes('..')) return json(res, 400, {error:'Bad request'});
  const fp = path.join(ROOT, file);
  fs.readFile(fp, (err, data) => {
    if (err) return json(res, 404, {error:'Not found'});
    const ext = path.extname(fp).toLowerCase();
    const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
    res.writeHead(200, {'Content-Type':types[ext] || 'application/octet-stream','Cache-Control':'no-store'});
    res.end(data);
  });
}

const server = http.createServer(serve);
const wss = new WebSocket.Server({server});

function send(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}
function getRoom(roomId) {
  if (!rooms.has(roomId)) rooms.set(roomId, new Map());
  return rooms.get(roomId);
}
function broadcast(room, payload, exceptId) {
  for (const [id, peer] of room) if (id !== exceptId) send(peer.ws, payload);
}
function removePeer(ws) {
  const roomId = ws.__roomId;
  const userId = ws.__userId;
  if (!roomId || !userId) return;
  const room = rooms.get(roomId);
  if (!room) return;
  room.delete(userId);
  broadcast(room, {type:'peer-left', userId}, userId);
  if (!room.size) rooms.delete(roomId);
}

wss.on('connection', (ws) => {
  ws.__roomId = '';
  ws.__userId = '';

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === 'join') {
      const roomId = String(msg.room || 'a2l-demo').slice(0, 80);
      const userId = String(msg.userId || crypto.randomUUID()).slice(0, 80);
      const name = String(msg.name || 'A2L User').slice(0, 80);
      const room = getRoom(roomId);

      if (room.size >= MAX_ROOM_SIZE && !room.has(userId)) {
        send(ws, {type:'room-full', max:MAX_ROOM_SIZE});
        ws.close(1008, 'Room full');
        return;
      }

      ws.__roomId = roomId;
      ws.__userId = userId;
      const existing = [...room.entries()].map(([id,p]) => ({userId:id,name:p.name}));
      room.set(userId, {ws,name});
      send(ws, {type:'joined', userId, room:roomId, peers:existing});
      broadcast(room, {type:'peer-joined', userId, name}, userId);
      return;
    }

    const roomId = ws.__roomId;
    const userId = ws.__userId;
    if (!roomId || !userId) return;
    const room = rooms.get(roomId);
    if (!room) return;

    if (msg.type === 'chat-message') {
      broadcast(room, {
        type:'chat-message',
        from:userId,
        name:String(msg.name || 'A2L User').slice(0,80),
        chatId:String(msg.chatId || '').slice(0,120),
        text:String(msg.text || '').slice(0,4000),
        at:Date.now(),
        messageId:`${userId}_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`
      }, userId);
      return;
    }

    if (['offer','answer','ice'].includes(msg.type)) {
      const targetId = String(msg.to || '');
      const target = room.get(targetId);
      if (!target) return;
      send(target.ws, {
        type:msg.type,
        from:userId,
        to:targetId,
        offer:msg.offer,
        answer:msg.answer,
        candidate:msg.candidate
      });
      return;
    }

    if (msg.type === 'presence') {
      broadcast(room, {type:'presence', from:userId, state:msg.state === 'active' ? 'active' : 'idle'}, userId);
    }
  });

  ws.on('close', () => removePeer(ws));
  ws.on('error', () => removePeer(ws));
});

server.listen(PORT, HOST, () => console.log(`A2L realtime server listening on ${HOST}:${PORT}`));
